#pragma once

#include <ros/ros.h>
#include <nav_core/base_local_planner.h>
#include <costmap_2d/costmap_2d_ros.h>
#include <costmap_2d/costmap_2d.h>
#include <geometry_msgs/Twist.h>
#include <geometry_msgs/PoseStamped.h>
#include <nav_msgs/Path.h>
#include <tf2_ros/buffer.h>
#include <tf2/utils.h>
#include <angles/angles.h>
#include <gazebo_msgs/ModelStates.h>

#include "Simulator.h"
#include "Vector2.h"

#include <string>
#include <vector>
#include <unordered_map>
#include <memory>
#include <mutex>
#include <cmath>
#include <algorithm>

namespace hrvo_local_planner {

// ---------------------------------------------------------------------------
// Inline helpers
// ---------------------------------------------------------------------------

static inline double getYaw(const geometry_msgs::PoseStamped& ps)
{
  return tf2::getYaw(ps.pose.orientation);
}

static inline double dist2D(const geometry_msgs::PoseStamped& a,
                            const geometry_msgs::PoseStamped& b)
{
  const double dx = a.pose.position.x - b.pose.position.x;
  const double dy = a.pose.position.y - b.pose.position.y;
  return std::hypot(dx, dy);
}

static inline double clamp(double v, double lo, double hi)
{
  return std::max(lo, std::min(hi, v));
}

// ---------------------------------------------------------------------------
// HRVOLocalPlanner
// ---------------------------------------------------------------------------

class HRVOLocalPlanner : public nav_core::BaseLocalPlanner
{
public:
  struct OtherAgent
  {
    std::string   name;
    hrvo::Vector2 pos;
    hrvo::Vector2 vel;
    float         radius{0.3f};

    // có thể giữ lại dù bản .cpp hiện tại chưa dùng trực tiếp
    hrvo::Vector2 est_goal;
  };

  HRVOLocalPlanner();
  ~HRVOLocalPlanner() override = default;

  // nav_core interface
  void initialize(std::string name,
                  tf2_ros::Buffer* tf,
                  costmap_2d::Costmap2DROS* costmap_ros) override;

  bool setPlan(const std::vector<geometry_msgs::PoseStamped>& orig_global_plan) override;
  bool computeVelocityCommands(geometry_msgs::Twist& cmd_vel) override;
  bool isGoalReached() override;

private:
  // --- Core helpers ---
  bool getRobotPose(geometry_msgs::PoseStamped& pose_out) const;
  geometry_msgs::PoseStamped getLookaheadTarget(
      const geometry_msgs::PoseStamped& robot_pose) const;
  std::vector<OtherAgent> buildOtherAgents() const;
  void resetSimulator(const geometry_msgs::PoseStamped& robot_pose,
                      const geometry_msgs::PoseStamped& target);

  bool isStateSafe(double x, double y) const;
  bool isCmdSafe(const geometry_msgs::PoseStamped& robot_pose,
                 const geometry_msgs::Twist& cmd) const;

  geometry_msgs::Twist fallbackCmd(const geometry_msgs::PoseStamped& robot_pose,
                                   const geometry_msgs::PoseStamped& target) const;

  void publishLocalPlanRollout(const geometry_msgs::PoseStamped& robot_pose,
                               double vx, double vy) const;

  // --- Gazebo callback ---
  void modelStatesCb(const gazebo_msgs::ModelStates::ConstPtr& msg);

  // -------------------------------------------------------------------------
  // ROS handles
  // -------------------------------------------------------------------------
  tf2_ros::Buffer*          tf_{nullptr};
  costmap_2d::Costmap2DROS* costmap_ros_{nullptr};
  costmap_2d::Costmap2D*    costmap_{nullptr};
  ros::Publisher            local_plan_pub_;
  ros::Subscriber           model_states_sub_;
  bool                      initialized_{false};

  // -------------------------------------------------------------------------
  // Plan & goal
  // -------------------------------------------------------------------------
  std::vector<geometry_msgs::PoseStamped> global_plan_;
  geometry_msgs::PoseStamped              goal_;

  // -------------------------------------------------------------------------
  // HRVO simulator
  // -------------------------------------------------------------------------
  std::unique_ptr<hrvo::Simulator> sim_;
  bool         sim_initialized_{false};
  std::size_t  robot_agent_id_{0};
  std::size_t  robot_goal_id_{0};
  hrvo::Vector2 last_goal_pos_{0.f, 0.f};
  int          step_count_{0};

  // map tên model -> id agent trong simulator
  mutable std::unordered_map<std::string, std::size_t> other_agent_ids_;

  // có thể giữ lại để tương thích với ý tưởng goal riêng cho agent khác
  // dù bản .cpp hiện tại chưa dùng đến
  mutable std::unordered_map<std::string, std::size_t> other_goal_ids_;

  // -------------------------------------------------------------------------
  // Gazebo model states
  // -------------------------------------------------------------------------
  gazebo_msgs::ModelStates last_model_states_;
  bool                     have_model_states_{false};
  ros::Time                last_model_states_stamp_;

  // -------------------------------------------------------------------------
  // Parameters
  // -------------------------------------------------------------------------

  // diff-drive limits
  double max_vel_x_{0.8};
  double max_vel_theta_{1.0};
  double acc_lim_x_{1.0};
  double acc_lim_theta_{2.0};

  // goal tolerance / tracking
  double xy_goal_tol_{0.2};
  double yaw_goal_tol_{0.2};
  double lookahead_dist_{0.8};

  // HRVO sim params
  double neighbor_dist_{6.0};
  int    max_neighbors_{25};
  double robot_radius_{0.30};
  double goal_radius_{0.20};
  double pref_speed_{0.4};
  double max_speed_{0.6};
  double uncertainty_offset_{0.15};
  double max_accel_{1.0};
  double time_step_{0.1};

  // heading controller
  double heading_kp_{2.0};
  bool   slowdown_cos_{true};
  double stop_yaw_error_{1.2};

  // sim reset policy
  int    goal_reset_every_{200};
  double goal_update_dist_{0.35};
  double min_vnorm_dir_{1e-3};

  // estimated goal cho agent khác
  double agent_goal_lookahead_{2.0};
  double agent_moving_thr_{0.05};

  // Gazebo agent detection
  bool        use_gazebo_agents_{true};
  std::string robot_model_name_;
  std::string other_model_prefix_;
  bool        include_humans_{true};
  std::string gazebo_frame_{"world"};
  std::string human_prefix_{"human"};
  double      human_radius_{0.45};

  // robustness
  bool   allow_world_as_global_when_tf_fails_{true};
  double model_states_timeout_{0.5};

  // costmap safety
  bool   use_costmap_safety_{true};
  int    obstacle_cost_threshold_{253};
  double safety_rollout_time_{1.0};
  double safety_dt_{0.1};
  double safety_radius_padding_{0.03};

  // runtime state
  geometry_msgs::Twist last_cmd_;
  ros::Time            last_time_;
};

} // namespace hrvo_local_planner
