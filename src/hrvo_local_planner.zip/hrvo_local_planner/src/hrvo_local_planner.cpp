// FILE: include/hrvo/hrvo_local_planner.h
#pragma once

#include <nav_core/base_local_planner.h>
#include <costmap_2d/costmap_2d_ros.h>
#include <tf2_ros/buffer.h>

#include <geometry_msgs/Twist.h>
#include <geometry_msgs/PoseStamped.h>

#include <hrvo/Simulator.h>
#include <hrvo/Vector2.h>

namespace hrvo_local_planner {

class HRVOLocalPlanner : public nav_core::BaseLocalPlanner {
public:
  HRVOLocalPlanner();
  ~HRVOLocalPlanner() override = default;

  void initialize(std::string name, tf2_ros::Buffer* tf, costmap_2d::Costmap2DROS* costmap_ros) override;
  bool setPlan(const std::vector<geometry_msgs::PoseStamped>& orig_global_plan) override;
  bool computeVelocityCommands(geometry_msgs::Twist& cmd_vel) override;
  bool isGoalReached() override;

private:
  bool initialized_{false};
  tf2_ros::Buffer* tf_{nullptr};
  costmap_2d::Costmap2DROS* costmap_ros_{nullptr};

  std::vector<geometry_msgs::PoseStamped> global_plan_;
  geometry_msgs::PoseStamped goal_;

  // move_base params
  double max_vel_x_{0.5};
  double max_vel_theta_{1.0};
  double xy_goal_tol_{0.2};
  double yaw_goal_tol_{0.2};
  double lookahead_dist_{0.8};

  // HRVO params
  double neighbor_dist_{5.0};
  int max_neighbors_{20};
  double robot_radius_{0.30};
  double goal_radius_{0.20};
  double pref_speed_{0.4};
  double max_speed_{0.6};
  double uncertainty_offset_{0.0};
  double max_accel_{1.0};
  double time_step_{0.1};

  // diff-drive mapping
  double heading_kp_{2.0};
  bool slowdown_cos_{true};
  double stop_yaw_error_{1.2};

  // HRVO sim
  hrvo::Simulator sim_;
  std::size_t robot_goal_id_{0};
  std::size_t robot_agent_id_{0};
  bool sim_initialized_{false};

  geometry_msgs::PoseStamped getLookaheadTarget(const geometry_msgs::PoseStamped& robot_pose) const;

  static double clamp(double v, double lo, double hi);
};

}  // namespace hrvo_local_planner