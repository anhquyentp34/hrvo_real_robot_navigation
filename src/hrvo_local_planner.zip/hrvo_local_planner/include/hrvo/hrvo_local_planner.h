#include <hrvo/hrvo_local_planner.h>

#include <pluginlib/class_list_macros.h>
#include <tf2/utils.h>
#include <angles/angles.h>

#include <algorithm>
#include <cmath>

namespace hrvo_local_planner {

static inline double hypot2(double x, double y) { return std::hypot(x, y); }

double HRVOLocalPlanner::clamp(double v, double lo, double hi) {
  return std::max(lo, std::min(v, hi));
}

HRVOLocalPlanner::HRVOLocalPlanner() : sim_() {}

void HRVOLocalPlanner::initialize(std::string name, tf2_ros::Buffer* tf, costmap_2d::Costmap2DROS* costmap_ros) {
  if (initialized_) return;

  tf_ = tf;
  costmap_ros_ = costmap_ros;

  ros::NodeHandle nh("~/" + name);

  // move_base style params
  nh.param("max_vel_x", max_vel_x_, 0.5);
  nh.param("max_vel_theta", max_vel_theta_, 1.0);
  nh.param("xy_goal_tolerance", xy_goal_tol_, 0.2);
  nh.param("yaw_goal_tolerance", yaw_goal_tol_, 0.2);
  nh.param("lookahead_dist", lookahead_dist_, 0.8);

  // HRVO params
  nh.param("neighbor_dist", neighbor_dist_, 5.0);
  nh.param("max_neighbors", max_neighbors_, 20);
  nh.param("robot_radius", robot_radius_, 0.30);
  nh.param("goal_radius", goal_radius_, 0.20);
  nh.param("pref_speed", pref_speed_, 0.4);
  nh.param("max_speed", max_speed_, 0.6);
  nh.param("uncertainty_offset", uncertainty_offset_, 0.0);
  nh.param("max_accel", max_accel_, 1.0);
  nh.param("time_step", time_step_, 0.1);

  // diff-drive mapping
  nh.param("heading_kp", heading_kp_, 2.0);
  nh.param("slowdown_cos", slowdown_cos_, true);
  nh.param("stop_yaw_error", stop_yaw_error_, 1.2);

  initialized_ = true;
}

bool HRVOLocalPlanner::setPlan(const std::vector<geometry_msgs::PoseStamped>& orig_global_plan) {
  if (!initialized_) return false;
  global_plan_ = orig_global_plan;
  if (!global_plan_.empty()) goal_ = global_plan_.back();
  return true;
}

geometry_msgs::PoseStamped HRVOLocalPlanner::getLookaheadTarget(const geometry_msgs::PoseStamped& robot_pose) const {
  // Simple lookahead: pick first plan point farther than lookahead_dist from robot
  if (global_plan_.empty()) return robot_pose;

  const double rx = robot_pose.pose.position.x;
  const double ry = robot_pose.pose.position.y;

  for (const auto& p : global_plan_) {
    const double dx = p.pose.position.x - rx;
    const double dy = p.pose.position.y - ry;
    if (std::hypot(dx, dy) >= lookahead_dist_) return p;
  }
  return global_plan_.back();
}

bool HRVOLocalPlanner::computeVelocityCommands(geometry_msgs::Twist& cmd_vel) {
  if (!initialized_ || global_plan_.empty()) return false;

  geometry_msgs::PoseStamped robot_pose;
  if (!costmap_ros_->getRobotPose(robot_pose)) return false;

  const double rx = robot_pose.pose.position.x;
  const double ry = robot_pose.pose.position.y;
  const double r_yaw = tf2::getYaw(robot_pose.pose.orientation);

  // goal distance check
  const double gx = goal_.pose.position.x;
  const double gy = goal_.pose.position.y;
  const double dist_to_goal = hypot2(gx - rx, gy - ry);

  geometry_msgs::Twist out;

  // Goal reached in xy: align yaw at goal
  if (dist_to_goal < xy_goal_tol_) {
    const double goal_yaw = tf2::getYaw(goal_.pose.orientation);
    const double yaw_err = angles::shortest_angular_distance(r_yaw, goal_yaw);
    out.linear.x = 0.0;
    out.angular.z = clamp(yaw_err, -max_vel_theta_, max_vel_theta_);
    cmd_vel = out;
    return true;
  }

  // Pick a short-term target on global plan
  const auto target = getLookaheadTarget(robot_pose);
  const double tx = target.pose.position.x;
  const double ty = target.pose.position.y;

  // Initialize HRVO sim once (agent 0 = robot)
  if (!sim_initialized_) {
    sim_.setTimeStep(static_cast<float>(time_step_));

    // Create a goal for the robot (will be updated each cycle)
    robot_goal_id_ = sim_.addGoal(hrvo::Vector2(static_cast<float>(tx), static_cast<float>(ty)));

    // Add robot agent at current pose, goal = robot_goal_id_
    // Using addAgent(position, goalNo, neighborDist, maxNeighbors, radius, goalRadius, prefSpeed, maxSpeed, uncertaintyOffset, maxAccel, velocity, orientation)
    robot_agent_id_ = sim_.addAgent(
      hrvo::Vector2(static_cast<float>(rx), static_cast<float>(ry)),
      robot_goal_id_,
      static_cast<float>(neighbor_dist_),
      static_cast<std::size_t>(std::max(1, max_neighbors_)),
      static_cast<float>(robot_radius_),
      static_cast<float>(goal_radius_),
      static_cast<float>(pref_speed_),
      static_cast<float>(max_speed_),
      static_cast<float>(uncertainty_offset_),
      static_cast<float>(max_accel_),
      hrvo::Vector2(0.0f, 0.0f),
      static_cast<float>(r_yaw)
    );

    sim_initialized_ = true;
  }

  // Update robot pose and goal in sim every cycle
  sim_.setAgentPosition(robot_agent_id_, hrvo::Vector2(static_cast<float>(rx), static_cast<float>(ry)));
  sim_.setAgentOrientation(robot_agent_id_, static_cast<float>(r_yaw));

  // Update goal: easiest is add a new goal and repoint agent to it (library has no "setGoalPosition")
  // This avoids touching private Goal internals.
  robot_goal_id_ = sim_.addGoal(hrvo::Vector2(static_cast<float>(tx), static_cast<float>(ty)));
  sim_.setAgentGoal(robot_agent_id_, robot_goal_id_);

  // TODO: Add neighbors (other agents) here:
  // - If you have tracked humans/robots: for each neighbor, create/update agent in sim_ with its position & velocity.
  // - Right now, without neighbors, HRVO will basically output toward goal.

  // Step HRVO once -> updates each agent's velocity internally
  sim_.doStep();

  const hrvo::Vector2 v = sim_.getAgentVelocity(robot_agent_id_);
  const double vx = static_cast<double>(v.getX());
  const double vy = static_cast<double>(v.getY());

  // Map holonomic (vx, vy) -> diff-drive (v, w)
  const double vnorm = std::hypot(vx, vy);
  const double vdir = std::atan2(vy, vx);
  const double yaw_err = angles::shortest_angular_distance(r_yaw, vdir);

  // If vector points "behind" too much, rotate in place
  if (std::fabs(yaw_err) > stop_yaw_error_) {
    out.linear.x = 0.0;
    out.angular.z = clamp(heading_kp_ * yaw_err, -max_vel_theta_, max_vel_theta_);
    cmd_vel = out;
    return true;
  }

  double v_cmd = std::min(vnorm, max_vel_x_);
  if (slowdown_cos_) {
    v_cmd *= std::max(0.0, std::cos(yaw_err));
  }

  out.linear.x = clamp(v_cmd, 0.0, max_vel_x_);
  out.angular.z = clamp(heading_kp_ * yaw_err, -max_vel_theta_, max_vel_theta_);

  cmd_vel = out;
  return true;
}

bool HRVOLocalPlanner::isGoalReached() {
  if (!initialized_ || global_plan_.empty()) return false;

  geometry_msgs::PoseStamped robot_pose;
  if (!costmap_ros_->getRobotPose(robot_pose)) return false;

  const double rx = robot_pose.pose.position.x;
  const double ry = robot_pose.pose.position.y;
  const double r_yaw = tf2::getYaw(robot_pose.pose.orientation);

  const double gx = goal_.pose.position.x;
  const double gy = goal_.pose.position.y;
  const double dist = hypot2(gx - rx, gy - ry);

  const double g_yaw = tf2::getYaw(goal_.pose.orientation);
  const double yaw_err = std::fabs(angles::shortest_angular_distance(r_yaw, g_yaw));

  return (dist < xy_goal_tol_) && (yaw_err < yaw_goal_tol_);
}

}  // namespace hrvo_local_planner

PLUGINLIB_EXPORT_CLASS(hrvo_local_planner::HRVOLocalPlanner, nav_core::BaseLocalPlanner)
